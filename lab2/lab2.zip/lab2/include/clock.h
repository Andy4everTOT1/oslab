#pragma once

#include "defs.h"

extern uint64_t ticks;

void clock_init();
void clock_set_next_event();

