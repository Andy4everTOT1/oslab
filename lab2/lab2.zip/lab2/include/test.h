#pragma once

int test();
void init_test_case();
